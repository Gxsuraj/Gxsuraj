str = input("Enter the string: ")
if "name" in str:
    print("Yes")
else:
    print("No")
