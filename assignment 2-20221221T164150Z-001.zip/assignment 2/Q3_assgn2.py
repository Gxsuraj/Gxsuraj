a = 56
b = 10
print("a & b =", a&b)
print("a | b =", a|b)
print("a ^ b =", a^b)
print("Left shifting both a and b with 2 bits =", a<<2, "=", b<<2)
print("Right shifting a with 2 bits and b with 4 bits =", a>>2, "=", b<<4)