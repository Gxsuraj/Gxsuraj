name = "ABC"
SID = "2210XXXX"
department = "XYZ"
CGPA = 9.9
print("Hey,", name, "Here!\nMy SID is", SID, "\nI am from", department, "department and my CGPA is", CGPA)